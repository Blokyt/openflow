import { useEffect, useState } from "react";
import { useFiscalYear } from "../../../core/FiscalYearContext";
import { useEntity } from "../../../core/EntityContext";
import { api } from "../../../api";
import { formatEuros, budgetColor } from "../../../utils/format";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";


export default function BudgetOverview() {
  const { selectedYear } = useFiscalYear();
  const { selectedEntityId, selectedEntity } = useEntity();
  const [categories, setCategories] = useState<any[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!selectedYear) { setCategories(null); return; }
    let cancelled = false;
    setCategories(null);
    setError(null);
    api.getBudgetCategoryView(selectedYear.id, selectedEntityId ?? undefined)
      .then((d: any) => {
        if (!cancelled) {
          // Filtrer pour ne garder que les catégories avec un budget alloué, ou avec des dépenses réalisées
          const relevant = d.categories.filter((c: any) => c.allocated > 0 || c.realized > 0);
          // Trier par dépassement / pourcentage consommé décroissant
          relevant.sort((a: any, b: any) => {
            const pctA = a.allocated > 0 ? a.realized / a.allocated : (a.realized > 0 ? Infinity : 0);
            const pctB = b.allocated > 0 ? b.realized / b.allocated : (b.realized > 0 ? Infinity : 0);
            return pctB - pctA;
          });
          setCategories(relevant);
        }
      })
      .catch((e: any) => { if (!cancelled) setError(e?.message || "Erreur lors du chargement du budget."); });
    return () => { cancelled = true; };
  }, [selectedYear?.id, selectedEntityId]);

  if (!selectedYear) {
    return (
      <div className="bg-bg-card border border-border rounded-2xl p-6 h-full flex flex-col">
        <p className="text-xs font-medium text-[#8a8a8a] uppercase tracking-wider mb-3">État des Budgets</p>
        <p className="text-sm text-[#8a8a8a]">
          <Link to="/budget" className="text-accent-sand hover:underline">Crée un exercice</Link> pour activer le suivi.
        </p>
      </div>
    );
  }
  if (error) {
    return (
      <div className="bg-bg-card border border-border rounded-2xl p-6 h-full flex flex-col">
        <p className="text-xs font-medium text-[#8a8a8a] uppercase tracking-wider mb-3">État des Budgets</p>
        <p className="text-sm text-alert">{error}</p>
      </div>
    );
  }
  if (!categories) {
    return (
      <div className="bg-bg-card border border-border rounded-2xl p-6 h-full flex flex-col">
        <p className="text-xs font-medium text-[#8a8a8a] uppercase tracking-wider mb-3">État des Budgets</p>
        <div className="h-2 bg-[#1a1a1a] rounded-full overflow-hidden mb-3 animate-pulse" />
        <p className="text-sm text-[#8a8a8a]">Chargement…</p>
      </div>
    );
  }

  const title = selectedEntity 
    ? `État des Budgets · ${selectedEntity.name}`
    : `État des Budgets`;

  return (
    <div className="bg-bg-card border border-border rounded-2xl p-6 flex flex-col h-full max-h-[400px]">
      <div className="flex items-center justify-between mb-4 gap-2">
        <p className="text-xs font-medium text-[#8a8a8a] uppercase tracking-wider truncate min-w-0">{title}</p>
        <Link to="/budget" className="text-xs text-accent-sand hover:underline inline-flex items-center gap-0.5 flex-shrink-0">
          Détail <ArrowRight size={11} />
        </Link>
      </div>
      
      {categories.length === 0 ? (
        <p className="text-sm text-[#8a8a8a]">
          Aucun budget alloué ni de dépenses sur ce périmètre.{" "}
          <Link to="/budget" className="text-accent-sand hover:underline">Budgéter</Link>
        </p>
      ) : (
        <div className="space-y-4 overflow-y-auto pr-2 custom-scrollbar">
          {categories.map((c) => {
            const hasBudget = c.allocated > 0;
            const pct = hasBudget ? (c.realized / c.allocated) * 100 : (c.realized > 0 ? 100 : 0);
            const isOver = hasBudget && c.realized > c.allocated;
            const barColor = hasBudget ? budgetColor(pct) : c.color || "#FF5252";
            
            return (
              <div key={c.category_id}>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-text-secondary truncate pr-2">{c.category_name}</span>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <span className={`font-medium ${isOver ? 'text-alert' : 'text-white'}`}>
                      {formatEuros(c.realized)}
                    </span>
                    {hasBudget ? (
                      <span className="text-[#8a8a8a]">/ {formatEuros(c.allocated)}</span>
                    ) : (
                      <span className="text-alert font-medium">(Hors budget)</span>
                    )}
                  </div>
                </div>
                <div className="h-1.5 bg-[#1a1a1a] rounded-full overflow-hidden flex">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(pct, 100)}%`, backgroundColor: barColor }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
