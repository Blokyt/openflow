import { useEffect, useState } from "react";
import { api } from "../api";
import { DashboardSummary } from "../types";
import { TrendingUp, TrendingDown, Hash, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { useEntity } from "./EntityContext";
import { useFiscalYear } from "./FiscalYearContext";
import ModuleDiscoveryHint from "./ModuleDiscoveryHint";
import OnboardingChecklist from "./OnboardingChecklist";
import BudgetOverview from "../modules/budget/widgets/BudgetOverview";
import { formatEuros, formatDate, txTone, COLOR_EXPENSE, COLOR_INCOME } from "../utils/format";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";

interface TimePoint { month: string; balance: number; }
interface TopCat { name: string; color: string; total: number; }
interface RecentTx {
  id: number; date: string; label: string; amount: number;
  from_entity_name?: string; to_entity_name?: string;
  from_entity_type?: string; to_entity_type?: string;
  category_name?: string; category_color?: string;
}

function SummaryCard({
  label, value, icon: Icon, valueColor,
}: {
  label: string; value: string; icon: React.ElementType; valueColor: string;
}) {
  return (
    <div className="bg-[#111] border border-[#222] rounded-2xl p-6 flex items-center gap-4">
      <div className="p-3 rounded-xl bg-[#1a1a1a] border border-[#222]">
        <Icon size={20} strokeWidth={1.5} className="text-[#B0B0B0]" />
      </div>
      <div>
        <p className="text-xs font-medium text-[#8a8a8a] uppercase tracking-wider mb-1">{label}</p>
        <p className={`text-xl font-bold ${valueColor}`}>{value}</p>
      </div>
    </div>
  );
}

function niceStep(range: number): number {
  const candidates = [50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000];
  for (const c of candidates) {
    if (range / c <= 6) return c;
  }
  return 100000;
}

function labelFor(m: string): string {
  const [y, mo] = m.split("-");
  const names = ["jan", "fév", "mar", "avr", "mai", "jun", "jul", "aoû", "sep", "oct", "nov", "déc"];
  return `${names[parseInt(mo, 10) - 1]} ${y.slice(2)}`;
}

function BalanceTooltip({ active, payload, label }: {
  active?: boolean;
  payload?: Array<{ value: number }>;
  label?: string;
}) {
  if (!active || !payload || payload.length === 0 || !label) return null;
  return (
    <div style={{
      backgroundColor: "#1a1a1a",
      border: "1px solid #333",
      borderRadius: 8,
      padding: "8px 12px",
      color: "#fff",
      fontSize: 12,
    }}>
      <p style={{ color: "#B0B0B0", marginBottom: 4 }}>{label}</p>
      <p style={{ fontWeight: 600 }}>{formatEuros(payload[0].value)}</p>
    </div>
  );
}

function BalanceChart({ series }: { series: TimePoint[] }) {
  if (series.length < 2) {
    return (
      <div className="bg-[#111] border border-[#222] rounded-2xl p-6">
        <p className="text-xs font-medium text-[#8a8a8a] uppercase tracking-wider mb-3">Évolution du solde</p>
        <p className="text-sm text-[#8a8a8a]">Pas assez de données pour afficher un graphique.</p>
      </div>
    );
  }

  const values = series.map((s) => s.balance);
  const minV = Math.min(...values);
  const maxV = Math.max(...values);
  const hasNegative = minV < 0;
  const accentColor = hasNegative ? "#FF5252" : "#F2C48D";
  const gradientId = hasNegative ? "balanceGradRed" : "balanceGradGold";

  const range = maxV - minV || 1;
  const step = niceStep(range);
  const tickMin = Math.floor(minV / step) * step;
  const tickMax = Math.ceil(maxV / step) * step;
  const ticks: number[] = [];
  for (let t = tickMin; t <= tickMax; t += step) {
    ticks.push(t);
  }

  const data = series.map((s) => ({ ...s, label: labelFor(s.month) }));
  const xInterval = Math.max(0, Math.ceil(series.length / 6) - 1);

  return (
    <div className="bg-[#111] border border-[#222] rounded-2xl p-6">
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-medium text-[#8a8a8a] uppercase tracking-wider">Évolution du solde</p>
        <p className="text-xs text-[#8a8a8a]">{series.length} mois</p>
      </div>
      <ResponsiveContainer width="100%" height={180}>
        <AreaChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={accentColor} stopOpacity={0.35} />
              <stop offset="100%" stopColor={accentColor} stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="#1a1a1a" vertical={false} />
          <XAxis
            dataKey="label"
            tick={{ fill: "#666", fontSize: 10 }}
            axisLine={false}
            tickLine={false}
            interval={xInterval}
          />
          <YAxis
            ticks={ticks}
            // Sans domain explicite, recharts garde [0, auto] : avec un solde à
            // 27 000 € la courbe s'écrase dans les 3 % du haut et devient invisible.
            domain={[ticks[0], ticks[ticks.length - 1]]}
            tickFormatter={(v: number) => `${(v / 100).toLocaleString("fr-FR", { maximumFractionDigits: 0 })} €`}
            tick={{ fill: "#666", fontSize: 10 }}
            axisLine={false}
            tickLine={false}
            width={55}
          />
          <Tooltip content={<BalanceTooltip />} />
          <Area
            type="monotone"
            dataKey="balance"
            stroke={accentColor}
            strokeWidth={2}
            fill={`url(#${gradientId})`}
            dot={false}
            activeDot={{ r: 4, fill: accentColor, strokeWidth: 0 }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function TopCategories({ cats }: { cats: TopCat[] }) {
  if (cats.length === 0) return null;
  const max = Math.max(...cats.map((c) => c.total));
  return (
    <div className="bg-[#111] border border-[#222] rounded-2xl p-6">
      <p className="text-xs font-medium text-[#8a8a8a] uppercase tracking-wider mb-4">Top dépenses par catégorie</p>
      <div className="space-y-3">
        {cats.map((c) => (
          <div key={c.name}>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-[#B0B0B0]">{c.name}</span>
              <span className="text-white font-medium">{formatEuros(c.total)}</span>
            </div>
            <div className="h-1.5 bg-[#1a1a1a] rounded-full overflow-hidden">
              <div
                className="h-full rounded-full"
                style={{ width: `${(c.total / max) * 100}%`, backgroundColor: c.color }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function RecentTransactions({ txs }: { txs: RecentTx[] }) {
  return (
    <div className="bg-[#111] border border-[#222] rounded-2xl p-6">
      <div className="flex items-center justify-between mb-4">
        <p className="text-xs font-medium text-[#8a8a8a] uppercase tracking-wider">Dernières transactions</p>
        <Link to="/transactions" className="text-xs text-[#F2C48D] hover:underline inline-flex items-center gap-0.5">
          Voir tout <ArrowRight size={11} />
        </Link>
      </div>
      {txs.length === 0 ? (
        <p className="text-sm text-[#8a8a8a]">Aucune transaction.</p>
      ) : (
        <div className="space-y-2">
          {txs.map((t) => (
            <div key={t.id} className="flex items-center justify-between gap-3 py-1.5">
              <div className="min-w-0 flex-1">
                <p className="text-sm text-white font-medium truncate">{t.label}</p>
                <p className="text-xs text-[#8a8a8a]">
                  {formatDate(t.date)} · {t.from_entity_name || "—"} → {t.to_entity_name || "—"}
                </p>
              </div>
              {(() => {
                const { color, sign } = txTone(t);
                return (
                  <p className="text-sm font-semibold whitespace-nowrap" style={{ color }}>
                    {sign}{formatEuros(t.amount)}
                  </p>
                );
              })()}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Dashboard() {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [series, setSeries] = useState<TimePoint[]>([]);
  const [cats, setCats] = useState<TopCat[]>([]);
  const [recent, setRecent] = useState<RecentTx[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const { selectedEntityId, selectedEntity } = useEntity();
  const { selectedYear } = useFiscalYear();

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    const eid = selectedEntityId ?? undefined;
    const today = new Date().toISOString().slice(0, 10);
    const dateFrom = selectedYear?.start_date;
    const dateTo = selectedYear ? (selectedYear.end_date ?? today) : undefined;
    Promise.all([
      api.getSummary(eid, dateFrom, dateTo),
      // Le graphe suit la même fenêtre que le reste : l'exercice sélectionné.
      api.getTimeseries(eid, 12, dateFrom, dateTo),
      api.getTopCategories(eid, 5, dateFrom, dateTo),
      api.getRecentTransactions(eid, 5, dateFrom, dateTo),
    ])
      .then(([s, ts, tc, rt]) => {
        // Garde anti-course : si l'entité/exercice a changé pendant le
        // chargement, cet effet est déjà obsolète, on ignore sa réponse.
        if (cancelled) return;
        setSummary(s);
        setSeries(ts);
        setCats(tc);
        setRecent(rt);
      })
      .catch((e) => {
        if (!cancelled) setError(e.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => { cancelled = true; };
  }, [selectedEntityId, selectedYear?.id, selectedYear?.start_date, selectedYear?.end_date]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-[#F2C48D]" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8">
        <div className="bg-[#1a0a0a] border border-[#FF5252]/30 text-[#FF5252] rounded-2xl p-4">{error}</div>
      </div>
    );
  }

  if (!summary) return null;
  const balancePositive = summary.balance >= 0;

  return (
    <div className="p-8 space-y-6">
      {summary.transaction_count === 0 && <OnboardingChecklist />}
      <ModuleDiscoveryHint />
      <div>
        <p className="text-sm font-medium text-[#8a8a8a] uppercase tracking-wider mb-2">Solde actuel</p>
        <div className="relative inline-block">
          {/* Halo dans l'accent doré de la marque (l'ancien bleu était un vestige). */}
          <div className="absolute -inset-4 bg-[rgba(242,196,141,0.07)] rounded-3xl blur-xl pointer-events-none" />
          <h1
            className={`relative text-5xl font-bold tracking-tight ${balancePositive ? "text-white" : "text-[#FF5252]"}`}
            style={{ letterSpacing: "-0.02em" }}
          >
            {formatEuros(summary.balance)}
          </h1>
        </div>
        {selectedEntity && (
          <p className="mt-3 text-sm text-[#8a8a8a]">
            Périmètre : <span className="text-[#F2C48D] font-medium">{selectedEntity.name}</span>
            {selectedEntity.children && selectedEntity.children.length > 0 && " et sous-entités"}
            {" "}(solde consolidé)
          </p>
        )}
        {summary.reference_date && summary.reference_amount !== undefined && (
          <p className="mt-3 text-sm text-[#8a8a8a]">
            Référence au{" "}
            <span className="text-[#B0B0B0] font-medium">{formatDate(summary.reference_date)}</span>{" "}:{" "}
            <span className="text-[#B0B0B0] font-medium">{formatEuros(summary.reference_amount)}</span>
          </p>
        )}
      </div>

      {selectedYear && (
        <p className="-mb-2 text-xs text-[#8a8a8a]">
          Activité de l'exercice <span className="text-[#F2C48D] font-medium">{selectedYear.name}</span>
        </p>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <SummaryCard label="Recettes" value={formatEuros(summary.total_income)} icon={TrendingUp} valueColor="text-[#00C853]" />
        <SummaryCard label="Dépenses" value={formatEuros(summary.total_expenses)} icon={TrendingDown} valueColor="text-[#FF5252]" />
        <SummaryCard label="Transactions" value={String(summary.transaction_count)} icon={Hash} valueColor="text-white" />
      </div>

      <BalanceChart series={series} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <BudgetOverview />
        <TopCategories cats={cats} />
        <RecentTransactions txs={recent} />
      </div>
    </div>
  );
}
