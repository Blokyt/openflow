import os
import re
from pathlib import Path

SRC_DIR = Path(r"C:\Users\bloki\Desktop\OpenFlow\openflow\frontend\src")

# Pattern for local spinner divs
SPINNER_PATTERN = re.compile(r'<div\s+className="animate-spin\s+rounded-full\s+h-\d+(?:\.\d+)?\s+w-\d+(?:\.\d+)?\s+border-b(?:-\d+)?\s+border-[^"]+"\s*/>')

def get_import_path(filepath):
    # Calculate relative path to core/PageLoader
    rel_path = filepath.relative_to(SRC_DIR)
    depth = len(rel_path.parts) - 1
    if depth == 0:
        return "./core/PageLoader"
    elif depth == 1:
        return "../core/PageLoader"
    elif depth == 2:
        return "../../core/PageLoader"
    elif depth == 3:
        return "../../../core/PageLoader"
    return "../../core/PageLoader" # default for modules/xxx/

files_changed = 0

for root, _, files in os.walk(SRC_DIR):
    for filename in files:
        if filename.endswith(".tsx"):
            filepath = Path(root) / filename
            if "PageLoader.tsx" in filename or "Spinner.tsx" in filename:
                continue
                
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            original_content = content
            
            # Replace spinner
            if SPINNER_PATTERN.search(content):
                content = SPINNER_PATTERN.sub('<PageLoader fullScreen={false} />', content)
                
                # Add import if not present
                if "PageLoader" not in original_content:
                    import_path = get_import_path(filepath)
                    import_stmt = f'import PageLoader from "{import_path}";\n'
                    # insert after last import
                    lines = content.split('\n')
                    last_import_idx = -1
                    for i, line in enumerate(lines):
                        if line.startswith('import '):
                            last_import_idx = i
                    
                    if last_import_idx >= 0:
                        lines.insert(last_import_idx + 1, import_stmt.strip())
                    else:
                        lines.insert(0, import_stmt.strip())
                    content = '\n'.join(lines)
                
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"Replaced spinner in: {filepath}")
                files_changed += 1

print(f"Total files updated for spinners: {files_changed}")
