import os
import re
from pathlib import Path

# Paths
SRC_DIR = Path(r"C:\Users\bloki\Desktop\OpenFlow\openflow\frontend\src")

# Regex substitutions
SUBS = [
    # Red
    (r'text-\[#FF5252\]', 'text-alert'),
    (r'bg-\[#FF5252\]', 'bg-alert'),
    (r'border-\[#FF5252\]', 'border-alert'),
    (r'hover:bg-\[#FF5252\]', 'hover:bg-alert'),
    
    # Green
    (r'text-\[#00C853\]', 'text-success'),
    (r'bg-\[#00C853\]', 'bg-success'),
    (r'border-\[#00C853\]', 'border-success'),
    
    # Sand
    (r'text-\[#F2C48D\]', 'text-accent-sand'),
    (r'bg-\[#F2C48D\]', 'bg-accent-sand'),
    (r'border-\[#F2C48D\]', 'border-accent-sand'),
    (r'focus:border-\[#F2C48D\]', 'focus:border-accent-sand'),
    (r'hover:bg-\[#e8b87a\]', 'hover:bg-accent-sand'),
    (r'hover:bg-\[#e5b57a\]', 'hover:bg-accent-sand'),
    
    # Border
    (r'border-\[#222\]', 'border-border'),
    (r'border-\[#222222\]', 'border-border'),
    (r'border-\[#333\]', 'border-border-hover'),
    (r'border-\[#333333\]', 'border-border-hover'),
    
    # Text
    (r'text-\[#B0B0B0\]', 'text-text-secondary'),
    (r'text-\[#666\]', 'text-text-muted'),
    (r'text-\[#666666\]', 'text-text-muted'),
    (r'placeholder-\[#444\]', 'placeholder-text-muted'),
    
    # Backgrounds
    (r'bg-\[#111\]', 'bg-bg-card'),
    (r'bg-\[#111111\]', 'bg-bg-card'),
    (r'bg-\[#080808\]', 'bg-bg-subtle'),
]

files_changed = 0

for root, _, files in os.walk(SRC_DIR):
    for filename in files:
        if filename.endswith(".tsx") or filename.endswith(".ts"):
            filepath = os.path.join(root, filename)
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            original_content = content
            
            for pattern, replacement in SUBS:
                content = re.sub(pattern, replacement, content, flags=re.IGNORECASE)
                
            if content != original_content:
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"Updated colors in: {filepath}")
                files_changed += 1

print(f"Total files updated for colors: {files_changed}")
