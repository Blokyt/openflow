# Bulk replace hardcoded hex colors in Tailwind utility classes with design tokens
# Run from frontend/src directory

$srcDir = "C:\Users\bloki\Desktop\OpenFlow\openflow\frontend\src"

# Ordered replacements: most specific first to avoid partial matches
$replacements = [ordered]@{
    # ===== Accent sand (F2C48D) =====
    'hover:bg-[#e8b87a]'         = 'hover:bg-accent-sand/80'
    'hover:text-[#e8b87a]'       = 'hover:text-accent-sand/80'
    'focus-within:border-[#F2C48D]' = 'focus-within:border-accent-sand'
    'focus:border-[#F2C48D]/50'  = 'focus:border-accent-sand/50'
    'focus:border-[#F2C48D]'     = 'focus:border-accent-sand'
    'hover:border-[#F2C48D]'     = 'hover:border-accent-sand'
    'hover:text-[#F2C48D]'       = 'hover:text-accent-sand'
    'hover:bg-[#F2C48D]/10'      = 'hover:bg-accent-sand/10'
    'border-[#F2C48D]/40'        = 'border-accent-sand/40'
    'border-[#F2C48D]/30'        = 'border-accent-sand/30'
    'bg-[#F2C48D]/10'            = 'bg-accent-sand/10'
    'border-b-2 border-[#F2C48D]' = 'border-b-2 border-accent-sand'
    'text-[#F2C48D]'             = 'text-accent-sand'
    'bg-[#F2C48D]'               = 'bg-accent-sand'
    'border-[#F2C48D]'           = 'border-accent-sand'

    # ===== Alert red (FF5252) =====
    'hover:text-[#FF5252]'       = 'hover:text-alert'
    'hover:bg-[#FF5252]'         = 'hover:bg-alert'
    'border-[#FF5252]/30'        = 'border-alert/30'
    'border-[#FF5252]/20'        = 'border-alert/20'
    'text-[#FF5252]/70'          = 'text-alert/70'
    'bg-[#FF5252]/10'            = 'bg-alert/10'
    'border-[#FF5252]/30'        = 'border-alert/30'
    'bg-[#FF5252]'               = 'bg-alert'
    'text-[#FF5252]'             = 'text-alert'
    'border-[#FF5252]'           = 'border-alert'

    # ===== Success green (00C853) =====
    'hover:text-[#00C853]'       = 'hover:text-success'
    'text-[#00C853]'             = 'text-success'
    'bg-[#00C853]'               = 'bg-success'
    'border-[#00C853]'           = 'border-success'

    # ===== Background card (111) =====
    'bg-[#111111]'               = 'bg-bg-card'
    'bg-[#111]'                  = 'bg-bg-card'

    # ===== Background subtle (080808) =====
    'bg-[#080808]'               = 'bg-bg-subtle'

    # ===== Border default (222) =====
    'hover:bg-[#222]'            = 'hover:bg-border'
    'border-[#222222]'           = 'border-border'
    'border-[#222]'              = 'border-border'
    'bg-[#222]'                  = 'bg-border'

    # ===== Border hover (333) =====
    'hover:border-[#333]'        = 'hover:border-border-hover'
    'border-[#333333]'           = 'border-border-hover'
    'border-[#333]'              = 'border-border-hover'

    # ===== Text secondary (B0B0B0) =====
    'disabled:hover:text-[#B0B0B0]' = 'disabled:hover:text-text-secondary'
    'text-[#B0B0B0]'             = 'text-text-secondary'

    # ===== Text muted (666) =====
    'placeholder-[#666]'         = 'placeholder-text-muted'
    'text-[#666666]'             = 'text-text-muted'
    'text-[#666]'                = 'text-text-muted'

    # ===== Placeholder muted (444) =====
    'placeholder-[#444]'         = 'placeholder-text-muted'
    'text-[#444]'                = 'text-text-muted'

    # ===== Hover border (444) =====
    'hover:border-[#444]'        = 'hover:border-border-hover'
}

$files = Get-ChildItem -Path $srcDir -Recurse -Include *.tsx,*.ts
$totalReplacements = 0
$changedFiles = @()

foreach ($file in $files) {
    $content = [System.IO.File]::ReadAllText($file.FullName)
    $original = $content
    
    foreach ($key in $replacements.Keys) {
        $escapedKey = [regex]::Escape($key)
        $count = ([regex]::Matches($content, $escapedKey)).Count
        if ($count -gt 0) {
            $content = $content.Replace($key, $replacements[$key])
            $totalReplacements += $count
        }
    }
    
    if ($content -ne $original) {
        [System.IO.File]::WriteAllText($file.FullName, $content)
        $changedFiles += $file.FullName
        Write-Host "  MODIFIED: $($file.Name)"
    }
}

Write-Host ""
Write-Host "=== SUMMARY ==="
Write-Host "Files changed: $($changedFiles.Count)"
Write-Host "Total replacements: $totalReplacements"
Write-Host ""
Write-Host "Changed files:"
$changedFiles | ForEach-Object { Write-Host "  $_" }
