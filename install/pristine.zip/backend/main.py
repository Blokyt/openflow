"""OpenFlow FastAPI application."""
import importlib
from dataclasses import asdict
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend.core.config import load_config, save_config
from backend.core.database import set_db_path
from backend.core.module_loader import discover_modules, filter_active


def _bootstrap_admin(db_path: Path):
    """Create default admin user (admin/admin) if no users exist."""
    import sqlite3
    from datetime import datetime, timezone
    from backend.modules.multi_users.api import _hash_password

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    try:
        count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        if count > 0:
            return

        now = datetime.now(timezone.utc).isoformat()
        password_hash = _hash_password("admin")

        conn.execute(
            """INSERT INTO users (username, password_hash, role, display_name, created_at, active)
               VALUES ('admin', ?, 'admin', 'Administrateur', ?, 1)""",
            (password_hash, now),
        )
        admin_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Assign admin as trésorier of root entity
        root = conn.execute(
            "SELECT id FROM entities WHERE is_default = 1 AND parent_id IS NULL"
        ).fetchone()
        if root:
            conn.execute(
                "INSERT INTO user_entities (user_id, entity_id, role) VALUES (?, ?, 'tresorier')",
                (admin_id, root[0]),
            )

        conn.commit()
        print(f"  Bootstrap: admin user created (login: admin / password: admin)")
    except Exception as e:
        print(f"  Bootstrap admin skipped: {e}")
    finally:
        conn.close()


def create_app(config_path: str = "config.yaml", db_path: str = "data/openflow.db") -> FastAPI:
    app = FastAPI(title="OpenFlow", version="0.1.0")

    project_root = Path(__file__).parent.parent
    config_file = project_root / config_path
    config = load_config(str(config_file))

    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

    # Auth middleware — only active when multi_users module is enabled
    if config.modules.get("multi_users", False):
        from backend.core.auth import AuthMiddleware
        app.add_middleware(AuthMiddleware)

    modules_dir = project_root / "backend" / "modules"
    all_modules = discover_modules(str(modules_dir))
    active_modules = filter_active(all_modules, config.modules)

    set_db_path(project_root / db_path)

    for manifest in active_modules:
        module_id = manifest["id"]
        for route_file in manifest.get("api_routes", []):
            route_path = modules_dir / module_id / route_file
            if route_path.exists():
                module_name = f"backend.modules.{module_id}.{route_file.replace('.py', '')}"
                try:
                    mod = importlib.import_module(module_name)
                    if hasattr(mod, "router"):
                        app.include_router(mod.router, prefix=f"/api/{module_id}", tags=[manifest["name"]])
                except Exception as e:
                    print(f"Warning: failed to load routes for {module_id}: {e}")

    # Bootstrap: create default admin user if multi_users is active and no users exist
    if config.modules.get("multi_users", False):
        _bootstrap_admin(project_root / db_path)

    @app.get("/api/modules")
    def get_modules():
        return active_modules

    @app.get("/api/modules/all")
    def get_all_modules():
        return all_modules

    @app.get("/api/config")
    def get_config():
        return asdict(config)

    @app.put("/api/config/entity")
    def update_entity(entity: dict):
        for key, value in entity.items():
            if hasattr(config.entity, key):
                setattr(config.entity, key, value)
        save_config(config, str(config_file))
        return asdict(config.entity)

    @app.put("/api/config/modules/{module_id}")
    def toggle_module(module_id: str, active: bool):
        if module_id not in config.modules:
            raise HTTPException(404, f"Module '{module_id}' not found")
        if active:
            module_manifest = next((m for m in all_modules if m["id"] == module_id), None)
            if module_manifest:
                for dep in module_manifest.get("dependencies", []):
                    if not config.modules.get(dep, False):
                        raise HTTPException(400, f"Cannot activate '{module_id}': dependency '{dep}' is not active")
        config.modules[module_id] = active
        save_config(config, str(config_file))
        return {"module_id": module_id, "active": active}

    @app.put("/api/config/balance")
    def update_balance(balance: dict):
        if "date" in balance:
            config.balance.date = balance["date"]
        if "amount" in balance:
            config.balance.amount = balance["amount"]
        save_config(config, str(config_file))
        return asdict(config.balance)

    build_dir = project_root / "frontend" / "dist"
    if build_dir.exists():
        # Serve static assets (JS, CSS, images)
        app.mount("/assets", StaticFiles(directory=str(build_dir / "assets")), name="assets")

        # SPA fallback: any non-API route serves index.html
        @app.get("/{path:path}")
        async def spa_fallback(path: str):
            file_path = build_dir / path
            if file_path.is_file():
                return FileResponse(str(file_path))
            return FileResponse(str(build_dir / "index.html"))

    return app
