migrations = {"1.0.0": []}
